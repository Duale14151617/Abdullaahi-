# POLICE HQ: administrative platform for Puntland's Police

> **Status: a fully functional system deployed on Render.**
> The system has been run on Render as a live web service backed by PostgreSQL, and **every part of it works**: sign-in with MFA,
> users and scoped roles, organization and structure, personnel, ranks, reports and approvals, attendance, vehicles, weapons,
> logistics, training, payroll and survivor benefits, analytics, audit log, dashboard, and the English/Somali interface on desktop and phone.

**Stack:** Django 5 + Django REST Framework, PostgreSQL, React + TypeScript (Vite), shipped as one Docker image and deployed on Render.
There is no XAMPP/WAMP/PHP in this project.

## What works today
| Area | What you can do |
|---|---|
| Sign-in and security | Session login with CSRF protection, lockout and throttling, TOTP MFA (mandatory for privileged roles), forced password change, "sign out everywhere". |
| Access control | Users, roles, permissions and scoped assignments (a unit and everything below it, optional service branch, validity dates). Deny by default; every check is made on the server. |
| Organization | HQ, regional commands, directorates, Guuto, Urur and battalion sections; unit tree; structure standards; governed structure changes (proposed by one person, approved by another). |
| Personnel | Records, effective-dated history (rank, unit, status), transfers, duplicate detection, CSV import preview and commit, profile tabs (personal information, service record, assignments, attendance, training, administrative history). |
| Ranks | Official 16-rank Army catalogue in English and Somali with draft and approval. |
| Reports and approvals | Configurable report and request types, draft to approved workflow, separation of duties, revisions, notifications, scoped summaries. |
| Attendance, vehicles, weapons | Daily attendance by unit, vehicle registry with maintenance and assignment history, weapon register, ammunition ledger and soldier holdings. |
| Logistics and training | Stock ledger, tracked assets, restricted equipment, reconciliation, course catalogue and training records. |
| Payroll and survivors | Payroll runs, salary profiles, payments, arrears, pay decisions and survivor benefits, each step needing a different person. |
| Dashboard and analytics | Role-aware operational dashboard (strength, attendance, pending approvals, logistics warnings, regional analytics, audit exceptions, administrative workload, security and system health) and an analytics page. |
| Audit | Append-only audit log with correlation IDs; failed and denied events surfaced on the dashboard. |
| Interface | English and Somali, light and dark mode, desktop and mobile layouts, universal search across the modules you are allowed to use, sortable and filterable data tables. |

## Deployment status
- **Deployed and run on Render** using `render.yaml` (one Docker web service plus a Postgres database). The container migrates, seeds reference data and
  the Police structure, and starts gunicorn on its own; sample accounts and sample people are created only when you ask for them (see *Deploy on Render*).
- **Everything above was exercised on that deployment** and works as described, including the weapon inventory and the consolidated sidebar. The tests have been run.
- **Sidebar:** the Logistics and equipment section has six entries; Ammunition, Weapons (register, inventory, holdings) and Military vehicles (with the equipment catalogue) show their pages as tabs.
- **No real data yet, by design:** no real data is hosted. Real personnel, payroll and equipment records will be loaded only after the Army approves.
- A standalone preview with built-in sample data can also run without a backend on Netlify (see *Frontend on Netlify*).

## Run it locally
Needs Python 3.12, Node 20+, PostgreSQL 16 (or Docker: `docker compose -f docker-compose.local.yml up`, see `docs/DOCKER_WINDOWS11.md`).

```bash
cp .env.example backend/.env          # fill DJANGO_SECRET_KEY and FIELD_ENCRYPTION_KEY (commands are in the file)
cd backend && pip install -r requirements-dev.txt
python manage.py migrate && python manage.py createcachetable
python manage.py seed_reference_data   # permissions, roles, branches, regions, ranks
python manage.py apply_army_structure --apply   # Police structure: HQ, directorates, regional commands, Guuto, Urur, battalion sections
python manage.py create_hq_admin --username admin --full-name "Admin" --role super_admin
python manage.py runserver
cd ../frontend && npm ci && npm run dev   # http://localhost:5173
python manage.py test                       # backend tests (from backend/)
cd frontend && npm test && npm run typecheck && npm run lint
```

## Deploy on Render
`render.yaml` is a Blueprint: one Docker web service plus a Postgres database. The container runs, in order: `migrate`,
`createcachetable`, `seed_reference_data`, `apply_army_structure --apply`, `seed_sample_data` (only when `ARMYHQ_SAMPLE_MODE=1`), `seed_test_personnel --from-env`, then gunicorn.
Set in the Render dashboard: `FIELD_ENCRYPTION_KEY` (keep it safe: losing it makes encrypted records unreadable), `ARMYHQ_SAMPLE_PASSWORD`,
and the switches below. See `RENDER_DEPLOY_GUIDE.md` and `docs/DEPLOY_ROLLBACK.md`.

| Variable | Effect |
|---|---|
| `ARMYHQ_SAMPLE_MODE=1` (older `ARMYHQ_DEMO_MODE` still works) | Creates the synthetic sample accounts and sample data (usernames in `docs/SETUP.md`, shared password from `ARMYHQ_SAMPLE_PASSWORD`; privileged sample roles enrol an authenticator app at first login). |
| `ARMYHQ_TEST_PERSONNEL=150` | Keeps 150 synthetic Army people. Unset/0 deletes them all. |
| `PERSONNEL_EXPORT_ENABLED`, `REPORT_EXPORT_ENABLED`, `INTEGRATIONS_ENABLED` | Stay 0 until the institution approves them. |

## Frontend on Netlify (no backend)
`cd frontend && npm run build:preview` builds a standalone preview with built-in sample data (no backend); `API_ORIGIN=https://your-backend npm run build:netlify`
builds against a real backend. Deploy `frontend/dist`, or connect the repo with Base directory `frontend`. See `docs/NETLIFY.md`.

## Army-only build
This build is Army-only.
Useful commands: `create_command_authority`, `report_duplicate_identities`, `seed_test_personnel`, `remove_legacy_structure`, `access_report`.

## Documentation
`docs/SETUP.md` (run it), `docs/DEPLOY_ROLLBACK.md` (migrations and rollback), `docs/RUNBOOK.md` (backup, restore, monitoring, incidents),
`docs/SECURITY.md`, `docs/LIMITATIONS.md`, `docs/ROLE_CATALOGUE.md` (what each role can do), `docs/INTEGRATIONS.md`, `CHANGELOG.md`.

## Release history
Administrative web platform for Puntland's Police. Stack: Django + DRF, PostgreSQL, React + TypeScript. Recent interface work (universal search,
shared data tables, personnel profile tabs, the redesigned dashboard) is listed in `CHANGELOG.md`.

## Included in 1.0
- Login (session cookie + CSRF), lockout, throttling, TOTP MFA (mandatory for privileged roles),
  forced password change, session revocation (disable, role revoke, admin "sign out everywhere").
- Users, roles, permissions, scoped role assignments (subtree of the organization + optional service branch,
  validity dates). Deny by default; every check is server-side.
- Configurable organization: HQ → region → branch command → unit. Seeded: Bari, Nugaal, Mudug;
  Army.
- Rank catalogue (service-specific, English/Somali, draft/approved), managed in the database. The Army list is the
  16 official Puntland Police ranks (Dable ... Sarreye Guud), stored as supplied with no invented translations.
- Organizational template for the Army: Taliska Guud (regional command), Qayb, Gaas, Guuto, Urur, Horin, Koox, Unug,
  with reference strengths (information only), approved strength exceptions, specialist designations (Sahan, Sanco) and
  expected-relationship checks, on the **Structure** page.
- Append-only audit log (model guard + PostgreSQL trigger), correlation IDs.
- Role-aware dashboard (real counts for scope/ranks/accounts/audit; clearly labelled synthetic sample figures).
- Somali/English UI, mobile-first (bottom nav on phones, sidebar on desktop).
- OpenAPI at `/api/v1/docs/` when `ENABLE_API_DOCS=1`.

## Added in 1.1 (Personnel)
- Personnel records: system ID, optional unique service number, name, phone, branch (derived from unit), unit,
  **approved** rank of the same branch, service status. Scoped on every list, detail, edit, search, history, import, export.
- Effective-dated history for rank, unit and status; transfer / change-rank / change-status workflows (no future-dated changes).
- Duplicate detection (service number hard-blocked; same name+phone/unit needs explicit confirmation).
- CSV import: preview (validated against *your* scope, no personal data echoed back) then commit (all-or-nothing, re-validated).
- CSV export: separate permission, **disabled unless `PERSONNEL_EXPORT_ENABLED=1`**, scoped, audited, formula-safe.
- Headquarters administrators get **no** personnel access by default; personnel permissions go to regional chiefs,
  branch/unit administrators, reporting users and read-only users within their scope.
- Personnel needs approved ranks: approve ranks (with Somali names) before adding people.

## Added in 1.2 (Requests, reports, approvals)
- Configurable request/report types (seeded: monthly administrative report with whitelisted numeric figures, transfer
  request, training request). HQ administrators can add types; types in use cannot change kind/figures.
- Workflow: draft → submitted → under review → approved / rejected / returned for correction; approved items can be
  amended and re-approved. Every submit creates an immutable revision; every step records actor, time, comment.
- Separation of duties per type (default on): nobody who submitted any revision can review it. Denials are audited.
- Identity, status, scope and approval state are never read from the client: actor = session, transitions only through
  action endpoints, scope enforced per item and per summary row, optimistic concurrency on every change.
- Summaries: approved content only, by region and consolidated, date/type/unit filters, limited to the caller's scope.
  A previously approved revision keeps counting while an amendment is pending.
- Notifications: submit/resubmit → reviewers in scope; review/decision → submitter. Private to the recipient and
  re-authorized when read (no title once scope is lost).
- Summary CSV export: own permission, **off unless `REPORT_EXPORT_ENABLED=1`**, scoped, audited, formula-safe.

## Added in 1.3 (Logistics and training)
- **Categories:** created by HQ administrators as drafts; usable only after *institutional review* by a separate
  `logistics_reviewer` (creator cannot approve; Somali name required; restricted categories need the stronger
  `logistics.restricted_approve`). Renaming an approved category sends it back for review.
- **Stock:** quantity lines per unit with an append-only ledger (receive / issue / adjust / transfer). Row-locked,
  never negative (also a database CHECK), optional `expected_balance` guard, reasons required for adjustments,
  transfers only into units you also manage.
- **Assets:** individually tracked items with unit-level issue/return, maintenance, missing/lost/retired, transfer, an
  accountable custodian (a user authorised for that unit) and a full event history.
- **Restricted equipment:** a separate permission (`logistics.restricted`) controls visibility *and* every action;
  restricted categories, items, reconciliations and summary rows are invisible to everyone else. The inventory has
  **no link to personnel records** (a test enforces this): items are accounted to units and custodians, never as a
  person-by-person assignment directory.
- **Reconciliation:** one open count per unit; variances become audited adjustments against the *current* balance;
  items not found become "missing", found ones are restored. Restricted lines only in restricted reconciliations.
- **Training:** HQ-managed course catalogue (English/Somali); records tied to personnel with a strict status flow
  (enrolled → in progress → completed/failed, or withdrawn), completion dates validated. Training staff pick people
  through a minimal roster (name + unit only) and get **no** general personnel access.
- **Summaries:** logistics (by category and region; stock totals, below-reorder, assets by status) and training
  (by course and region and status), both limited to the caller's scope.

## Added in 1.4 (Hardening: no new product features)
- Fixes found in review: rate-limit bypass through a spoofed `X-Forwarded-For`, TOTP code replay, no absolute session
  lifetime, admin-chosen recovery passwords (now one-time codes), timing difference for locked accounts, unprotected
  history tables (now PostgreSQL triggers), unaudited audit reads, unbounded request size, missing headers.
- Guard rails: `manage.py check --deploy` rules, secret redaction in logs, health endpoints, bulk-operation rate limit,
  retention job for CSV import data, `security_report` for alerting.
- Evidence: deny-by-default sweep over every route, cross-region canary matrix across all modules, CSRF/CORS/session/MFA/
  recovery tests, migration safety and query-count tests, PostgreSQL concurrency test.
- Operations: `docs/SECURITY.md` (findings, residual risks, items for independent review), `docs/RUNBOOK.md` (backup,
  restore, monitoring, incident response, rollback), `docs/TEST_PLAN_1.4.md`, `ops/` scripts, `deploy/` proxy template,
  `backend/Dockerfile`, CI workflow, accessibility/layout end-to-end scaffolding.


Not yet (by design): integrations/offline (2.0, only after institutional approval), tactical features.

See `docs/SETUP.md` to run it and `docs/DEPLOY_ROLLBACK.md` for migrations and rollback.

## Added in 2.0 (Institutional expansion; additive, 1.x contracts unchanged)
- **Analytics** (`/api/v1/analytics/`, page *Analytics*): aggregate personnel, reports, logistics and training figures with date and region filters. Needs `analytics.view` plus the section's existing permission; limited to the caller's scope; read-only; restricted equipment excluded.
- **Integration API** (`/api/v1/ext/`, admin at `/api/v1/integrations/clients/`, page *Integrations*): scoped, expiring, revocable bearer keys that read aggregate analytics only; small cells withheld; per-key rate limit; full call log. **Off unless `INTEGRATIONS_ENABLED=1`.** See `docs/INTEGRATIONS.md`.
- **Governed structure changes** (`/api/v1/organization/structure-changes/`, page *Structure changes*): levels (names, order, parents, strength standards) change only by proposal + approval by a different person (role *Structure approver*); direct edits refused by default (`STRUCTURE_CHANGES_REQUIRE_APPROVAL`). See `docs/STRUCTURE_APPROVAL.md`.
- **Unit tree** (`/api/v1/organization/units/tree/`, page *Unit tree*): scoped nested view of the organization.
- Not built: configurable top-level categories, outbound integrations, offline access (`docs/OFFLINE_DECISION.md`).
- Docs: `IMPACT_ASSESSMENT_v2.0.md`, `MIGRATION_PLAN_v2.0.md`, `SECURITY_REVIEW_v2.0.md`, `COMPATIBILITY_v2.0.md`, `CHANGE_REPORT_v2.0.0.md`.
- Upgrade: `migrate` then `seed_reference_data` (see `docs/MIGRATION_PLAN_v2.0.md`).


## Frontend on Netlify (2.1.2, no backend)
`cd frontend && npm run build:preview` builds a standalone preview with built-in sample data (no backend); `API_ORIGIN=https://your-backend npm run build:netlify`
builds against a real backend. Deploy `frontend/dist`, or connect the repo with Base directory `frontend`. See `docs/NETLIFY.md`.
