"""v1.4 -> v2.0 compatibility. v2.0 must only ADD: nothing a v1.4 client, role, route or table relied on may change.

The baselines below were extracted mechanically from the v1.4.0 sources (seed_reference_data.py and config/api_v1.py).
"""
import os
from pathlib import Path

from django.conf import settings
from django.db.migrations import operations as ops
from django.db.migrations.loader import MigrationLoader

from apps.accounts.models import Role
from apps.core.testing import BaseApiTest
from apps.core.management.commands.seed_reference_data import HQ_ADMIN_RESERVED, PERMISSIONS
from config.api_v1 import router

V14_ROLE_PERMISSIONS = {'auditor': ['audit.view', 'dashboard.view', 'org.view'],
 'branch_admin': ['dashboard.view', 'logistics.report', 'logistics.view', 'org.manage', 'org.view',
                  'personnel.import', 'personnel.manage', 'personnel.view', 'ranks.view', 'reports.review',
                  'reports.submit', 'reports.summary', 'reports.view', 'training.report', 'training.view'],
 'hq_admin': ['audit.view', 'dashboard.view', 'logistics.configure', 'org.manage', 'org.view',
              'ranks.approve', 'ranks.manage', 'ranks.view', 'reports.configure', 'roles.assign',
              'training.configure', 'users.manage', 'users.view'],
 'hq_reporting': ['dashboard.view', 'logistics.report', 'org.view', 'personnel.export', 'personnel.view',
                  'ranks.view', 'reports.export', 'reports.summary', 'reports.view', 'training.report'],
 'logistics_custodian': ['dashboard.view', 'logistics.manage', 'logistics.reconcile', 'logistics.report',
                         'logistics.view', 'org.view'],
 'logistics_reviewer': ['dashboard.view', 'logistics.approve', 'logistics.restricted_approve', 'org.view'],
 'read_only': ['dashboard.view', 'org.view', 'personnel.view', 'ranks.view', 'reports.view'],
 'regional_chief': ['dashboard.view', 'logistics.report', 'logistics.view', 'org.view', 'personnel.export',
                    'personnel.manage', 'personnel.view', 'ranks.view', 'reports.export', 'reports.review',
                    'reports.summary', 'reports.view', 'training.report', 'training.view'],
 'reporting_officer': ['dashboard.view', 'org.view', 'personnel.view', 'ranks.view', 'reports.submit',
                       'reports.view'],
 'restricted_custodian': ['dashboard.view', 'logistics.manage', 'logistics.reconcile', 'logistics.report',
                          'logistics.restricted', 'logistics.view', 'org.view'],
 'training_admin': ['dashboard.view', 'org.view', 'training.configure', 'training.manage', 'training.report',
                    'training.view'],
 'unit_admin': ['dashboard.view', 'logistics.view', 'org.manage', 'org.view', 'personnel.manage',
                'personnel.view', 'ranks.view', 'reports.submit', 'reports.view', 'training.view']}

V14_ROUTES = [('users', 'user'), ('roles', 'role'), ('organization/units', 'unit'),
 ('organization/unit-types', 'unit-type'), ('organization/designations', 'designation'),
 ('organization/designation-rules', 'designation-rule'), ('organization/structure', 'structure'),
 ('organization/branches', 'branch'), ('ranks', 'rank'), ('personnel', 'personnel'),
 ('reports/types', 'report-type'), ('reports/submissions', 'submission'),
 ('reports/summary', 'report-summary'), ('notifications', 'notification'),
 ('logistics/categories', 'inv-category'), ('logistics/stock', 'stock'), ('logistics/assets', 'asset'),
 ('logistics/reconciliations', 'reconciliation'), ('logistics/summary', 'logistics-summary'),
 ('training/courses', 'course'), ('training/records', 'training-record'),
 ('training/people', 'training-person'), ('training/summary', 'training-summary'),
 ('audit-events', 'audit-event')]

V14_MIGRATIONS = {
    "accounts": ["0001_initial", "0002_mfa_replay_and_password_reset"],
    "audit": ["0001_initial", "0002_immutability_trigger"],
    "logistics": ["0001_initial", "0002_append_only_triggers"],
    "organization": ["0001_initial", "0002_specialistdesignation_and_more", "0003_puntland_army_structure"],
    "personnel": ["0001_initial", "0002_append_only_triggers"],
    "ranks": ["0001_initial", "0002_alter_rank_category", "0003_official_puntland_army_ranks"],
    "training": ["0001_initial"],
    "workflows": ["0001_initial", "0002_append_only_triggers"],
}
NEW_PERMISSIONS = {"analytics.view", "integrations.view", "integrations.manage", "org.structure_propose", "org.structure_approve", "food.view", "food.manage", "changes.propose", "changes.approve", "tasks.view", "tasks.manage"}
ROLES_GAINING_ANALYTICS = {"hq_reporting", "regional_chief", "branch_admin"}
NEW_ROLES = {"structure_approver", "super_admin", "command_authority", "member", "unit_commander", "weapons_custodian", "regional_commander", "transport_officer", "vehicle_disposal_approver",
             "payroll_officer", "payroll_approver", "survivor_officer", "payment_officer", "payment_reconciler", "custody_officer", "tax_collector", "tax_cashier"}  # command: command authority; member: own record + direct subordinates
# branch_admin holds the sensitive personnel-file records (disciplinary history, service documents).
BRANCH_ADMIN_RECORDS = {"disciplinary.view", "disciplinary.manage", "documents.view", "documents.manage"}
# hq_admin receives every non-sensitive permission automatically, so it gains the integration and structure-proposal ones.
# Death workflow: units and regions may REPORT a death; only branch_admin may CONFIRM (a different officer from the reporter).
DEATH_GAINS = {"unit_admin": {"personnel.record_death"}, "regional_chief": {"personnel.record_death"},
               "branch_admin": {"personnel.record_death", "personnel.confirm_death", "personnel.appointments_manage"}}
# Withdrawn on purpose after 2.0: the headquarters administrator now PREPARES and the super administrator APPROVES (HQ_ADMIN_RESERVED).
HQ_ADMIN_WITHDRAWN = {"ranks.approve"}
HQ_ADMIN_GAINS = {"integrations.view", "integrations.manage", "org.structure_propose", "food.view", "food.manage", "changes.propose", "tasks.view", "tasks.manage"}


class RoleCompatibilityTests(BaseApiTest):
    def test_no_role_lost_a_permission(self):
        for role, codes in V14_ROLE_PERMISSIONS.items():
            have = set(Role.objects.get(code=role).permissions.values_list("code", flat=True))
            withdrawn = HQ_ADMIN_WITHDRAWN if role == "hq_admin" else set()
            self.assertFalse(set(codes) - have - withdrawn, f"{role} lost {set(codes) - have - withdrawn}")

    def test_roles_only_gained_the_documented_permission(self):
        for role, codes in V14_ROLE_PERMISSIONS.items():
            have = set(Role.objects.get(code=role).permissions.values_list("code", flat=True))
            gained = have - set(codes)
            allowed = ({"analytics.view"} if role in ROLES_GAINING_ANALYTICS else set()) | (HQ_ADMIN_GAINS if role == "hq_admin" else set())
            allowed |= BRANCH_ADMIN_RECORDS if role == "branch_admin" else set()
            allowed |= DEATH_GAINS.get(role, set())
            allowed |= {"weapons.view"} if role == "regional_chief" else set()  # regional chief views its region's weapon register
            allowed |= {"vehicles.view"} if role in ("regional_chief", "branch_admin") else set()  # vehicle register: oversight roles read it
            allowed |= {"vehicles.configure"} if role == "hq_admin" else set()  # HQ admin maintains the vehicle categories
            allowed |= {"payroll.view"} if role == "auditor" else set()  # the auditor reads payroll (regional finance), never acts on it
            if role == "hq_admin":  # every permission except the ones reserved for the super administrator
                allowed = set(PERMISSIONS) - HQ_ADMIN_RESERVED - set(codes)
            self.assertEqual(gained, allowed, role)

    def test_only_the_documented_role_was_added_and_none_removed(self):
        self.assertEqual(set(Role.objects.values_list("code", flat=True)), set(V14_ROLE_PERMISSIONS) | NEW_ROLES)

    def test_every_new_permission_is_registered(self):
        from apps.accounts.models import Permission
        self.assertTrue(NEW_PERMISSIONS <= set(Permission.objects.values_list("code", flat=True)))

    def test_administrators_hold_nothing_reserved_for_the_super_administrator(self):
        # Since 2.1 the headquarters administrator does the everyday work (people, stock, weapons, vehicles, training, accounts) but
        # holds no approval, money-movement, restricted or override authority: those stay with the super administrator.
        have = set(Role.objects.get(code="hq_admin").permissions.values_list("code", flat=True))
        self.assertFalse(have & set(HQ_ADMIN_RESERVED), have & set(HQ_ADMIN_RESERVED))
        self.assertTrue({"integrations.view", "org.structure_propose"} <= have)
        self.assertNotIn("integrations.manage", have)  # API clients are a back door: super administrator only
        self.assertNotIn("org.structure_approve", have)  # approving a structure change is a separate duty


class RouteCompatibilityTests(BaseApiTest):
    def test_every_v14_route_is_still_registered_under_the_same_name(self):
        now = {(prefix, basename) for prefix, _, basename in router.registry}
        missing = {tuple(r) for r in V14_ROUTES} - now
        self.assertFalse(missing, missing)

    def test_v2_adds_only_the_documented_routes(self):
        now = {(prefix, basename) for prefix, _, basename in router.registry}
        added = now - {tuple(r) for r in V14_ROUTES}
        self.assertEqual(added, {("analytics", "analytics"), ("integrations/clients", "integration-client"),
                                 ("organization/structure-changes", "structure-change"), ("organization/change-requests", "change-request"), ("operations/tasks", "unit-task"), ("logistics/suppliers", "food-supplier"), ("logistics/food/receipts", "food-receipt"), ("logistics/food/allocations", "food-allocation"), ("logistics/food/warnings", "food-warning"), ("logistics/food/options", "food-options"),
                                 ("reports/combined", "report-combined"),  # combined Army report
                                 ("attendance", "attendance"), ("weapons", "weapons"), ("vehicles", "vehicle"), ("logistics/ammunition", "ammunition"),
                                 ("survivor-cases", "survivor-case"), ("payroll/profiles", "payroll-profile"),
                                 ("payroll/runs", "payroll-run"), ("payroll/personnel", "payroll-personnel"),
                                 ("payroll/policy", "payroll-policy"), ("payroll/payments", "payroll-payment"),
                                 ("payroll/arrears", "payroll-arrears"),
                                 # organizational structure upgrade: department catalogue, unit departments, formation roles, org analytics
                                 ("organization/departments", "department"), ("organization/unit-departments", "unit-department"),
                                 ("organization/formation-roles", "formation-role"), ("organization/analytics", "org-analytics"),
                                 ("ammo-control", "ammo-control"),
                                 # modules added after 2.0: protective equipment, equipment/vehicle models, inventory catalogue
                                 ("ppe", "ppe"), ("equipment", "equipment"), ("inventories", "inventory"),
                                 # Police modules: detention register, custody facilities, occurrence book, vehicle log and tracking, taxes
                                 ("detention", "detention"), ("detention-oversight", "detention-oversight"), ("custody-facilities", "custody-facility"), ("occurrence-book", "occurrence-book"),
                                 ("vehicle-tracking", "vehicle-tracking"), ("vehicle-log", "vehicle-log"), ("tax", "tax")})  # attendance, weapons, ammunition and payroll modules

    def test_version_1_prefix_is_unchanged(self):
        self.assertEqual(self.client_for(self.make_user("hqr", "hq_reporting")).get("/api/v1/auth/me/").status_code, 200)

    def test_me_and_dashboard_keep_their_v14_shape(self):
        c = self.client_for(self.make_user("hqr", "hq_reporting"))
        me = c.get("/api/v1/auth/me/").json()
        for key in ("id", "username", "full_name", "preferred_language", "mfa_enabled", "requires_mfa", "restrictions",
                    "permissions", "features", "assignments"):
            self.assertIn(key, me)
        self.assertTrue({"personnel_export", "report_export"} <= set(me["features"]))
        self.assertIs(me["features"]["integrations"], False)  # off unless explicitly enabled
        dash = c.get("/api/v1/dashboard/").json()
        self.assertEqual(set(dash), {"scope", "ranks", "personnel", "reports"})  # no new blocks

    def test_exports_and_integrations_remain_off_by_default(self):
        self.assertFalse(settings.PERSONNEL_EXPORT_ENABLED)
        self.assertFalse(settings.REPORT_EXPORT_ENABLED)
        self.assertFalse(settings.INTEGRATIONS_ENABLED)


V2_ADDED_MIGRATIONS = {  # migrations added to existing apps after v1.4 (2.0 structure changes)
    "accounts": ["0003_mfa_recovery_code", "0004_email_verification", "0005_temp_password_expiry"],
    "organization": ["0004_structure_change", "0005_unit_restricted", "0006_station_level",
                     "0007_change_request", "0008_change_request_kinds", "0009_change_request_batch", "0010_change_request_rank_status",
                     "0011_remove_station_level", "0012_departments_and_formation_roles"],
    "ranks": ["0004_add_command_ranks", "0005_police_rank_categories", "0006_army_rank_categories"],
    "personnel": ["0003_personnelprofile", "0004_disciplinary_and_documents", "0005_supervisor_and_account",
                  "0006_death_record_and_statuses", "0007_command_appointments", "0008_attendance_support_category",
                  "0009_unit_tasks", "0010_scale_indexes", "0011_department_and_appointment_roles", "0012_strength_snapshot"],
    "logistics": ["0003_ammunition_ledger", "0004_food_stores", "0005_food_batch_opening_source", "0006_asset_lifecycle", "0007_stock_lot"],
}


class MigrationCompatibilityTests(BaseApiTest):
    def test_existing_apps_gained_only_the_documented_migration(self):
        loader = MigrationLoader(None, ignore_no_migrations=True)
        for app, names in V14_MIGRATIONS.items():
            have = sorted(n for (a, n) in loader.disk_migrations if a == app)
            self.assertEqual(have, sorted(names + V2_ADDED_MIGRATIONS.get(app, [])), app)

    def test_new_apps_only_create_things(self):
        loader = MigrationLoader(None, ignore_no_migrations=True)
        allowed = (ops.CreateModel, ops.AddIndex, ops.RunPython)
        for (app, name), migration in loader.disk_migrations.items():
            if app in ("analytics", "integrations") or (app, name) == ("organization", "0004_structure_change"):
                for op in migration.operations:
                    self.assertIsInstance(op, allowed, f"{app}.{name}: {type(op).__name__}")

    def test_new_tables_are_separate_from_v14_tables(self):
        from django.apps import apps
        names = {m._meta.db_table for m in apps.get_app_config("integrations").get_models()}
        self.assertEqual(names, {"integration_clients", "integration_calls"})
