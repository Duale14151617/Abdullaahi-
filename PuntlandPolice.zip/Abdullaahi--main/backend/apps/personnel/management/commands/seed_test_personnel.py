"""Synthetic test personnel for trials and load/UX testing - clearly tagged and removable in one go.

  python manage.py seed_test_personnel --count 150     add test people (idempotent: tops up to 150)
  python manage.py seed_test_personnel --delete        remove every test person (and their history/training rows)
  python manage.py seed_test_personnel --from-env      used at container start, see below

On Render (no shell on the free plan) the start command runs `--from-env`, driven by ONE environment variable:
  POLICEHQ_TEST_PERSONNEL=150   -> make sure 150 test Army people exist
  unset / 0                   -> delete all test people

Test people are identified ONLY by the service-number prefix "TST-", so real records are never touched.
Army test people are TST-0001...
Names are common Somali given names with father/grandfather names; no two test people share a name.
Each person also gets a complete identity profile (blood type, gender, date of birth, enlistment date, home district,
emergency contact, a weapon ID for about 3 in 4, and a neutral placeholder portrait).
"""
import random
from datetime import date, timedelta
from io import BytesIO

from django.core.management.base import BaseCommand, CommandError
from django.db import connection, transaction
from PIL import Image, ImageDraw

from apps.core import env as hqenv
from apps.organization.models import OrganizationalUnit as OU
from apps.personnel import profile as profile_svc
from apps.personnel import services as svc
from apps.personnel.models import Personnel, PersonnelHistory, PersonnelProfile
from apps.ranks.models import Rank

PREFIX = "TST-"
REGIONS = ("BARI", "NUGAAL", "MUDUG")

MALE = ["Abdirahman", "Abdullahi", "Abdiweli", "Abdikarim", "Abdinasir", "Abdisalam", "Abdulkadir", "Abshir", "Ahmed", "Ali",
        "Bashir", "Barre", "Dahir", "Elmi", "Farah", "Fuad", "Guled", "Hassan", "Hersi", "Hussein", "Ibrahim",
        "Ismail", "Jama", "Jibril", "Khalif", "Liban", "Mahad", "Mohamed", "Mukhtar", "Mustafe", "Nuur", "Omar", "Osman",
        "Said", "Samatar", "Shire", "Suleiman", "Warsame", "Yasin", "Yusuf", "Zakariye", "Abdiaziz", "Abdirizak",
        "Ayanle", "Deeq", "Faisal", "Gaas", "Idris", "Kaahin", "Mursal", "Salad", "Tahlil",
        "Yonis"]
FEMALE = ["Amina", "Asha", "Ayaan", "Deeqa", "Faduma", "Halima", "Hawa", "Hodan", "Ifrah", "Khadija", "Ladan",
          "Maryan", "Muna", "Nasra", "Rukia", "Sagal", "Sahra", "Ubah", "Zamzam"]
FAMILY = ["Abdi", "Abdullahi", "Adan", "Ahmed", "Ali", "Aw", "Barre", "Bile", "Botan", "Dahir", "Duale", "Egal", "Elmi",
          "Farah", "Gedi", "Guled", "Hassan", "Hussein", "Ibrahim", "Ismail", "Jama", "Jimcaale", "Kahin", "Khalif",
          "Liban", "Mohamud", "Muse", "Nur", "Omar", "Osman", "Qorane", "Robleh", "Saed", "Salah", "Samatar",
          "Sheikh", "Warsame", "Yare", "Yusuf"]
DISTRICTS = ["Garowe", "Bosaso", "Galkayo North", "Qardho", "Eyl", "Burtinle", "Dangorayo", "Iskushuban", "Bandarbeyla",
             "Jariban", "Gardo", "Caluula", "Bargaal", "Godobjiraan", "Goldogob", "Armo"]
BLOOD = ["O+"] * 8 + ["A+"] * 6 + ["B+"] * 4 + ["O-", "A-", "B-", "AB+", "AB-"]
BACKDROPS = [(28, 46, 78), (40, 58, 92), (52, 64, 84), (34, 52, 66), (60, 70, 96)]
STATUS = ["active"] * 17 + ["on_leave"] * 2 + ["suspended"]
# the 16 supplied ranks, junior -> senior; the two top appointments are left out. Junior ranks are more common.
WEIGHTS = [14, 12, 10, 9, 8, 7, 6, 5, 5, 4, 3, 3, 2, 2, 1, 1]


def _candidates(n, seed=20260):
    """Deterministic, unique-by-full-name list of (full_name) so reruns continue the same sequence."""
    rng = random.Random(seed)
    seen, out = set(), []
    while len(out) < n:
        first = rng.choice(FEMALE) if rng.random() < 0.12 else rng.choice(MALE)
        father, grand = rng.sample(FAMILY, 2)
        name = f"{first} {father} {grand}"
        key = svc.normalize_name(name)
        if key not in seen:
            seen.add(key)
            out.append(name)
    return out


def _units():
    units = []
    for r in REGIONS:
        cmd = OU.objects.filter(code=f"{r}-ARMY").first()
        if not cmd:
            continue
        unit = OU.objects.filter(code=f"{r}-ARMY-SAMPLE-A").first() or OU.objects.create(
            code=f"{r}-ARMY-SAMPLE-A", name_en="Synthetic Unit A", name_so="Cutubka Tijaabada A",
            level=OU.Level.UNIT, parent=cmd)
        units.append(unit)
    return units


def _placeholder_photo(rng):
    """Neutral silhouette on a dark blue backdrop (clearly not a real face) at the app's 360x450 portrait size."""
    w, h = profile_svc.PHOTO_SIZE
    img = Image.new("RGB", (w, h), rng.choice(BACKDROPS))
    d = ImageDraw.Draw(img)
    tone = (150, 160, 178)
    d.ellipse((w * .31, h * .17, w * .69, h * .50), fill=tone)             # head
    d.ellipse((w * .12, h * .56, w * .88, h * 1.25), fill=tone)            # shoulders
    d.rectangle((0, h - 6, w, h), fill=(196, 160, 60))                     # thin gold base line
    buf = BytesIO()
    img.save(buf, "JPEG", quality=80)
    return buf.getvalue()


def fill_profiles():
    """Give every test person a complete identity profile (blood type, gender, weapon ID, dates, district, emergency
    contact, placeholder photo). Only people whose profile is still empty are filled, so admin edits are never overwritten."""
    filled = 0
    today = date.today()
    for person in Personnel.objects.filter(service_number__startswith=PREFIX).order_by("service_number"):
        n = int(person.service_number[len(PREFIX):])
        rng = random.Random(9000 + n)
        existing = PersonnelProfile.objects.filter(pk=person.pk).first()
        if not (existing and existing.data_enc):
            first = person.full_name.split()[0]
            dob = today - timedelta(days=rng.randint(21 * 365, 48 * 365))
            earliest, latest = dob + timedelta(days=18 * 365 + 30), today - timedelta(days=60)
            enlisted = earliest + timedelta(days=rng.randint(0, (latest - earliest).days))
            contact_first = rng.choice(MALE + FEMALE)
            changes = {
                "blood_type": rng.choice(BLOOD), "gender": "female" if first in FEMALE else "male",
                "date_of_birth": dob, "enlistment_date": enlisted, "home_district": rng.choice(DISTRICTS),
                "emergency_contact_name": f"{contact_first} {rng.choice(FAMILY)}",
                "emergency_contact_phone": f"+252908{n:06d}",
            }
            if rng.random() < 0.75:  # not everyone is issued a personal weapon
                changes["weapon_id"] = f"TSTW-{n:04d}"
            profile_svc.save(person, changes)
            filled += 1
        if not (existing and existing.photo_enc):
            profile_svc.save_photo(person, _placeholder_photo(rng))
    return filled


def add_test_personnel(count):
    units = _units()
    ranks = list(Rank.objects.filter(branch__code="ARMY", approval_status=Rank.Approval.APPROVED, active=True)
                 .order_by("sort_order")[:16])
    if not units or not ranks:
        raise CommandError("Reference data missing (regional Police commands or approved ranks). Run seed_reference_data first.")
    have = set(Personnel.objects.filter(service_number__startswith=PREFIX).values_list("service_number", flat=True))
    taken = set(Personnel.objects.values_list("name_key", flat=True))
    names = _candidates(count + 400)  # spare names in case a real person already has one
    rng = random.Random(1)
    today, created, name_i = date.today(), 0, 0
    with transaction.atomic():
        for i in range(1, count + 1):
            number = f"{PREFIX}{i:04d}"
            if number in have:
                continue
            while svc.normalize_name(names[name_i]) in taken:
                name_i += 1
            name = names[name_i]
            name_i += 1
            taken.add(svc.normalize_name(name))
            # every rank appears at least once among the first people, then weighted towards junior ranks
            rank = ranks[(i - 1) % len(ranks)] if i <= len(ranks) else rng.choices(ranks, weights=WEIGHTS[:len(ranks)])[0]
            svc.create_personnel(
                None, full_name=name, phone=f"+252907{i:06d}", service_number=number, org_unit=units[(i - 1) % len(units)],
                rank=rank, status=rng.choice(STATUS), effective_date=today - timedelta(days=rng.randint(30, 1500)),
                reason="Synthetic test record")
            created += 1
    fill_profiles()  # also completes people created before profiles were added
    return created


def delete_test_personnel():
    """Remove every TST- person. History is append-only through the normal manager, so it is cleared with the plain
    base manager here; training rows protect the person, so they go first. Nothing else is touched."""
    from apps.training.models import TrainingRecord
    with transaction.atomic():
        from apps.personnel.models import DisciplinaryRecord, PersonnelDocument
        ids = list(Personnel.objects.filter(service_number__startswith=PREFIX).values_list("pk", flat=True))
        # Disciplinary entries are append-only and documents can never be deleted, so a test person who was given either
        # (someone trying the screens on the sample data) is kept rather than breaking the whole clean-up.
        held = set(DisciplinaryRecord.objects.filter(personnel_id__in=ids).values_list("personnel_id", flat=True))
        held |= set(PersonnelDocument.objects.filter(personnel_id__in=ids).values_list("personnel_id", flat=True))
        ids = [i for i in ids if i not in held]
        if not ids:
            return 0
        TrainingRecord.objects.filter(personnel_id__in=ids).delete()
        # On PostgreSQL a trigger makes personnel_history append-only. Synthetic TST- people are the one sanctioned
        # exception: the trigger is switched off inside this transaction only (DDL rolls back with it) and restored
        # before it commits.
        pg = connection.vendor == "postgresql"
        if pg:
            with connection.cursor() as cur:
                # ALTER TABLE is refused while deferred constraint checks are pending, so run them first.
                cur.execute("SET CONSTRAINTS ALL IMMEDIATE")
                cur.execute("ALTER TABLE personnel_history DISABLE TRIGGER personnel_history_no_change")
        PersonnelHistory._base_manager.filter(personnel_id__in=ids).delete()
        if pg:
            with connection.cursor() as cur:
                cur.execute("SET CONSTRAINTS ALL IMMEDIATE")
                cur.execute("ALTER TABLE personnel_history ENABLE TRIGGER personnel_history_no_change")
                cur.execute("SET CONSTRAINTS ALL DEFERRED")
        Personnel.objects.filter(pk__in=ids).delete()  # profile rows cascade
    return len(ids)


class Command(BaseCommand):
    help = "Add or remove clearly-tagged synthetic test personnel (service numbers TST-0001...)."

    def add_arguments(self, parser):
        g = parser.add_mutually_exclusive_group()
        g.add_argument("--count", type=int, help="make sure this many Army test people exist (max 1000)")
        g.add_argument("--delete", action="store_true", help="delete ALL test people")
        g.add_argument("--from-env", action="store_true", help="use POLICEHQ_TEST_PERSONNEL (0/unset = delete all)")

    def handle(self, *args, **opts):
        if opts["from_env"]:
            raw = hqenv.get("TEST_PERSONNEL", "0").strip()
            try:  # start-up must never fail because of test data
                n = max(0, min(int(raw or 0), 1000))
                if n:
                    self.stdout.write(f"Test personnel: {add_test_personnel(n)} added (target {n}).")
                else:
                    self.stdout.write(f"Test personnel: {delete_test_personnel()} removed.")
            except Exception as exc:  # noqa: BLE001
                self.stderr.write(f"Test personnel skipped: {exc}")
            return
        if opts["delete"]:
            self.stdout.write(self.style.SUCCESS(f"Deleted {delete_test_personnel()} test personnel."))
        elif opts["count"]:
            if not 1 <= opts["count"] <= 1000:
                raise CommandError("--count must be between 1 and 1000.")
            self.stdout.write(self.style.SUCCESS(f"Added {add_test_personnel(opts['count'])} test personnel."))
        else:
            raise CommandError("Use --count N, --delete or --from-env.")
