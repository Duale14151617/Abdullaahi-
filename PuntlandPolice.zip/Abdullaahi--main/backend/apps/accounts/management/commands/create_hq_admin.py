import getpass

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from apps.accounts.models import Role, RoleAssignment, User
from apps.accounts.serializers import check_password_strength
from apps.audit.services import record
from apps.core import env as hqenv
from apps.organization.models import OrganizationalUnit


class Command(BaseCommand):
    help = "Create the first headquarters administrator. Password is prompted (or POLICEHQ_ADMIN_PASSWORD)."

    def add_arguments(self, parser):
        parser.add_argument("--username", required=True)
        parser.add_argument("--full-name", required=True)
        parser.add_argument("--role", default="hq_admin", choices=["hq_admin", "super_admin"],
                            help="super_admin = every permission, HQ-wide (run seed_reference_data first)")

    @transaction.atomic
    def handle(self, *args, **opts):
        hq = OrganizationalUnit.objects.filter(level="headquarters").first()
        role = Role.objects.filter(code=opts["role"]).first()
        if not hq or not role:
            raise CommandError("Run `manage.py seed_reference_data` first.")
        username = opts["username"].lower()
        if User.objects.filter(username=username).exists():
            raise CommandError("That username already exists.")
        password = hqenv.get("ADMIN_PASSWORD") or getpass.getpass("Password: ")
        try:
            check_password_strength(password)
        except Exception as exc:  # DRF ValidationError or Django one
            raise CommandError(f"Weak password: {exc}")
        user = User.objects.create_user(username, password=password, full_name=opts["full_name"],
                                        must_change_password=True)
        RoleAssignment.objects.create(user=user, role=role, org_unit=hq)
        record("user.bootstrap_admin", actor=user, entity_type="user", entity_id=user.pk,
               metadata={"via": "management_command"})
        self.stdout.write(self.style.SUCCESS(
            f"Created {username}. First login requires a password change and MFA enrolment."))
