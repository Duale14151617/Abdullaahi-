"""Synthetic sample users and units. NEVER use with real data. Explicit sample mode only (ARMYHQ_SAMPLE_MODE; the older ARMYHQ_DEMO_* names still work)."""
import os

from django.conf import settings
from django.core.management import call_command
from django.core.management.base import BaseCommand, CommandError
from django.conf import settings
from django.db import transaction

from apps.accounts.models import Role, RoleAssignment, User
from apps.accounts.services import revoke_user_sessions, temp_password_deadline
from apps.organization.models import OrganizationalUnit as OU
from apps.organization.models import ServiceBranch
from apps.personnel import services as personnel_services
from apps.personnel.models import Personnel
from apps.ranks.models import Rank

# username: (full name, role, org unit code, branch code or None)
# Usernames have no "demo." prefix. Older deployments that already have "demo.<name>" accounts are renamed in place below.
def _env(new, old, default=""):
    """New variable name first; the old ARMYHQ_DEMO_* name keeps working so existing deployments need no dashboard change."""
    return os.environ.get(new) or os.environ.get(old, default)


SAMPLE_USERS = {
    "hqadmin": ("HQ Administrator", "hq_admin", "HQ", None),
    "superadmin": ("Super Administrator", "super_admin", "HQ", None),
    "hqreports": ("HQ Reporting", "hq_reporting", "HQ", None),
    "auditor": ("Auditor", "auditor", "HQ", None),
    "bari.chief": ("Bari Chief", "regional_chief", "BARI", None),
    "nugaal.chief": ("Nugaal Chief", "regional_chief", "NUGAAL", None),
    "bari.armyadmin": ("Bari Police Admin", "branch_admin", "BARI", "ARMY"),
    "bari.unitadmin": ("Bari Unit Admin", "unit_admin", "BARI-ARMY-SAMPLE-A", None),
    "bari.reporter": ("Bari Reporting Officer", "reporting_officer", "BARI-ARMY", None),
    "logistics": ("Logistics Custodian", "logistics_custodian", "BARI", None),
    "restricted": ("Restricted Custodian", "restricted_custodian", "BARI-ARMY", None),
    "reviewer": ("Logistics Reviewer", "logistics_reviewer", "HQ", None),
    "trainer": ("Training Administrator", "training_admin", "BARI", None),
    "readonly": ("Read-only", "read_only", "MUDUG", None),
}

# Non-commanding member: sees only their own record and the people who report to them (see _sample_team).
# Taliye Urur / Guuto stand-in: records attendance and makes the unit situation report for the synthetic unit.
SAMPLE_USERS.setdefault("bari.commander", ("Bari Unit Commander (Sample)", "unit_commander", "BARI-ARMY-SAMPLE-A", None))
SAMPLE_USERS.setdefault("bari.member", ("Bari Member (Sample Person 03)", "member", "BARI-ARMY-SAMPLE-A", None))
# Finance duties are split between four roles (the service layer refuses self-approval), so the payroll flow needs one account each.
SAMPLE_USERS.setdefault("payroll.officer", ("Payroll Officer", "payroll_officer", "HQ", None))
SAMPLE_USERS.setdefault("payroll.approver", ("Payroll Approver", "payroll_approver", "HQ", None))
SAMPLE_USERS.setdefault("payment.officer", ("Payment Execution Officer", "payment_officer", "HQ", None))
SAMPLE_USERS.setdefault("payment.reconciler", ("Payment Reconciliation Officer", "payment_reconciler", "HQ", None))
SAMPLE_USERS.setdefault("president", ("President / Commander-in-Chief", "command_authority", "HQ", None))
SAMPLE_USERS.setdefault("commander", ("Commander of the Puntland Defense Forces", "command_authority", "HQ", None))

# The other regions get the same regional set Bari has (chief, branch admin, unit admin, reporter, custodians, trainer).
OTHER_REGIONS = ("Nugaal", "Mudug")
for _name in OTHER_REGIONS:
    _r, _k = _name.upper(), _name.lower()
    SAMPLE_USERS.setdefault(f"{_k}.chief", (f"{_name} Chief", "regional_chief", _r, None))
    SAMPLE_USERS.setdefault(f"{_k}.armyadmin", (f"{_name} Police Admin", "branch_admin", _r, "ARMY"))
    SAMPLE_USERS.setdefault(f"{_k}.unitadmin", (f"{_name} Unit Admin", "unit_admin", f"{_r}-ARMY-SAMPLE-A", None))
    SAMPLE_USERS.setdefault(f"{_k}.reporter", (f"{_name} Reporting Officer", "reporting_officer", f"{_r}-ARMY", None))
    SAMPLE_USERS.setdefault(f"{_k}.logistics", (f"{_name} Logistics Custodian", "logistics_custodian", _r, None))
    SAMPLE_USERS.setdefault(f"{_k}.restricted", (f"{_name} Restricted Custodian", "restricted_custodian", f"{_r}-ARMY", None))
    SAMPLE_USERS.setdefault(f"{_k}.trainer", (f"{_name} Training Administrator", "training_admin", _r, None))


# Health Department of each Police regional command: a head who manages the department's people, and a reporting officer.
for _name in ("Bari", "Nugaal", "Mudug", "Sanaag"):  # the four Police regional commands
    _r = _name.upper()
    SAMPLE_USERS.setdefault(f"{_name.lower()}.health", (f"{_name} Health Department Head", "unit_admin", f"{_r}-ARMY-HEALTH", None))
    SAMPLE_USERS.setdefault(f"{_name.lower()}.healthofficer", (f"{_name} Health Reporting Officer", "reporting_officer", f"{_r}-ARMY-HEALTH", None))

# Regional finance pays that region's SALARIES (headquarters prepares and approves the monthly run). Four accounts per Police regional command, one
# per step so nobody approves their own work: prepare, authorize, send (outside the system) and reconcile. Roles are assigned at the command.
# A read-only auditor sits at the first battalion (Urur) of each command.
for _name in ("Bari", "Nugaal", "Mudug", "Sanaag"):
    _k, _r = _name.lower(), _name.upper()
    SAMPLE_USERS.setdefault(f"{_k}.fin.prepare", (f"{_name} Finance: Prepare Payments", "payroll_officer", f"{_r}-ARMY", None))
    SAMPLE_USERS.setdefault(f"{_k}.fin.authorize", (f"{_name} Finance: Authorize Payments", "payroll_approver", f"{_r}-ARMY", None))
    SAMPLE_USERS.setdefault(f"{_k}.fin.pay", (f"{_name} Finance: Send Payments", "payment_officer", f"{_r}-ARMY", None))
    SAMPLE_USERS.setdefault(f"{_k}.fin.reconcile", (f"{_name} Finance: Reconcile", "payment_reconciler", f"{_r}-ARMY", None))
    SAMPLE_USERS.setdefault(f"{_k}.audit.u1", (f"{_name} Battalion 1 Finance Auditor", "auditor", f"{_r}-ARMY-G1-U1", None))

# Roles that had no sample account. Survivor benefits need two people (one registers, another verifies), so there are two survivor officers.
# Arrears need a second payroll officer: one records the claim, a different one verifies it, then the approver decides.
SAMPLE_USERS.setdefault("payroll.officer2", ("Payroll Officer 2", "payroll_officer", "HQ", None))
SAMPLE_USERS.setdefault("structure.approver", ("Structure Approver", "structure_approver", "HQ", None))
SAMPLE_USERS.setdefault("survivor.officer", ("Survivor-Benefit Officer", "survivor_officer", "HQ", None))
SAMPLE_USERS.setdefault("survivor.verifier", ("Survivor-Benefit Verifier", "survivor_officer", "HQ", None))
# Taliye Qaybeed: one per Police regional command (assigned at the command, view and review of what its Guuto and Urur post).
for _name in ("Bari", "Nugaal", "Mudug", "Sanaag"):
    SAMPLE_USERS.setdefault(f"{_name.lower()}.regcommander", (f"{_name} Regional Commander (Taliye Qaybeed)", "regional_commander", f"{_name.upper()}-ARMY", None))

# One weapons custodian per Police regional command: register, issue and take back weapons in that region only.
for _name in ("Bari", "Nugaal", "Mudug", "Sanaag"):
    SAMPLE_USERS.setdefault(f"{_name.lower()}.weapons", (f"{_name} Weapons Custodian", "weapons_custodian", f"{_name.upper()}-ARMY", None))


# Vehicle register: the transport officer keeps it, a different person approves disposals.
SAMPLE_USERS.setdefault("transport.officer", ("Transport Officer", "transport_officer", "BARI", None))
SAMPLE_USERS.setdefault("vehicle.approver", ("Vehicle Disposal Approver", "vehicle_disposal_approver", "HQ", None))
SAMPLE_USERS.setdefault("custody.officer", ("Custody Officer", "custody_officer", "BARI", None))
SAMPLE_USERS.setdefault("custody.lead", ("Custody Lead", "custody_commander", "HQ", None))
SAMPLE_USERS.setdefault("tax.head", ("Tax Head", "tax_head", "HQ", None))
SAMPLE_USERS.setdefault("ministry.viewer", ("Ministry Viewer", "ministry_viewer", "HQ", None))
SAMPLE_USERS.setdefault("tax.collector", ("Tax Collector", "tax_collector", "BARI", None))
SAMPLE_USERS.setdefault("tax.cashier", ("Tax Cash Officer", "tax_cashier", "HQ", None))


# Sample accounts that stay enabled. Every other sample account is created DISABLED and is disabled again on each run, because they
# all share one seed password. Enable more only on purpose: ARMYHQ_SAMPLE_ACTIVE_USERS="superadmin,hqadmin,bari.reporter" (comma list).
DEFAULT_ACTIVE_SAMPLE_USERS = ("superadmin", "hqadmin")


def _active_sample_usernames():
    raw = os.environ.get("ARMYHQ_SAMPLE_ACTIVE_USERS")
    names = [n.strip().lower() for n in raw.split(",")] if raw is not None else list(DEFAULT_ACTIVE_SAMPLE_USERS)
    return {n for n in names if n}


class Command(BaseCommand):
    help = "Create synthetic sample accounts. Password from ARMYHQ_SAMPLE_PASSWORD (min 12 chars)."

    @transaction.atomic
    def handle(self, *args, **opts):
        # Production DEBUG stays off. This separate, explicit flag permits only synthetic sample fixtures
        # on a deliberately configured sample deployment; never enable it for real operational data.
        sample_mode = _env("ARMYHQ_SAMPLE_MODE", "ARMYHQ_DEMO_MODE", "0").strip().lower() in ("1", "true", "yes", "on")
        if not settings.DEBUG and not sample_mode:
            raise CommandError("Sample data is disabled. Set ARMYHQ_SAMPLE_MODE=1 only for a synthetic sample deployment.")
        password = _env("ARMYHQ_SAMPLE_PASSWORD", "ARMYHQ_DEMO_PASSWORD", "")
        if len(password) < 12:
            raise CommandError("Set ARMYHQ_SAMPLE_PASSWORD (12+ characters).")
        active_names = _active_sample_usernames()
        army_cmd = OU.objects.filter(code="BARI-ARMY").first()
        if not army_cmd:
            raise CommandError("Run `manage.py seed_reference_data` first.")
        # The supplied Police structure (Taliska Guud, directorates, Qaybta commands). Synthetic deployments only: a real
        # deployment applies it deliberately with `manage.py apply_army_structure` (dry run first).
        call_command("apply_army_structure", "--apply", stdout=self.stdout)
        OU.objects.filter(code="BARI-ARMY-SAMPLE-A").first() or OU.objects.create(
            code="BARI-ARMY-SAMPLE-A", name_en="Synthetic Unit A", name_so="Cutubka Tijaabada A",
            level=OU.Level.UNIT, parent=army_cmd)
        for region in OTHER_REGIONS:  # one synthetic unit per region so each region's unit admin has a unit
            region_army = OU.objects.filter(code=f"{region.upper()}-ARMY").first()
            if region_army:
                OU.objects.filter(code=f"{region.upper()}-ARMY-SAMPLE-A").first() or OU.objects.create(
                    code=f"{region.upper()}-ARMY-SAMPLE-A", name_en="Synthetic Unit A", name_so="Cutubka Tijaabada A",
                    level=OU.Level.UNIT, parent=region_army)
        for username, (full, role_code, unit_code, branch_code) in SAMPLE_USERS.items():
            multi = not isinstance(unit_code, str)  # several units: one role assignment per unit
            codes = [c for c in ([unit_code] if not multi else unit_code) if OU.objects.filter(code=c).exists()]
            if not codes:
                continue  # reference data for this region is missing; skip rather than fail the whole deploy
            legacy = User.objects.filter(username=f"demo.{username}").first()
            if legacy and not User.objects.filter(username=username).exists():
                legacy.username = username  # keep role assignment, password and MFA enrolment
                legacy.full_name = full
                legacy.save(update_fields=["username", "full_name", "updated_at"])
            user = User.objects.filter(username=username).first()
            if user:
                if username not in active_names and user.is_active:
                    User.objects.filter(pk=user.pk).update(is_active=False)  # shared seed password: off unless listed on purpose
                    revoke_user_sessions(user)
                if _env("ARMYHQ_SAMPLE_RESET", "ARMYHQ_DEMO_RESET", "0") == "1":
                    user.set_password(password)
                    user.must_change_password = True
                    user.temp_password_expires_at = temp_password_deadline()
                    user.failed_login_count = 0
                    user.locked_until = None
                    user.mfa_enabled = False
                    user.mfa_secret_enc = ""
                    user.save(update_fields=[
                        "password", "must_change_password", "temp_password_expires_at", "failed_login_count", "locked_until",
                        "mfa_enabled", "mfa_secret_enc", "updated_at",
                    ])
                if not multi:
                    continue
            else:
                # The shared seed password is only ever temporary: first sign-in forces a new one, and it expires.
                user = User.objects.create_user(
                    username, password=password, full_name=full, must_change_password=True,
                    temp_password_expires_at=temp_password_deadline(), is_active=username in active_names)
            role = Role.objects.get(code=role_code)
            branch = ServiceBranch.objects.get(code=branch_code) if branch_code else None
            if multi:  # drop any earlier Headquarters-wide assignment: this account is limited to the listed units
                RoleAssignment.objects.filter(user=user, role=role, org_unit__level=OU.Level.HQ).delete()
            for code in codes:
                RoleAssignment.objects.get_or_create(user=user, role=role, org_unit=OU.objects.get(code=code), branch=branch)
        self._sample_personnel(army_cmd)
        self._sample_team()
        self._sample_logistics_training()
        self.stdout.write(self.style.SUCCESS(
            f"Synthetic sample users ready. Enabled: {', '.join(sorted(active_names))}; all other sample accounts are disabled. "
            "Privileged roles must enrol MFA on first login."))

    def _sample_personnel(self, army_cmd):
        """Add a few clearly fake people (sample only). Ranks are the official approved Army ranks."""
        unit = OU.objects.get(code="BARI-ARMY-SAMPLE-A")
        if Personnel.objects.filter(org_unit=unit).exists():
            return
        for i in range(1, 9):
            rank = Rank.objects.get(branch=army_cmd.branch, code=("PA-01", "PA-03", "PA-05", "PA-10")[i % 4])
            personnel_services.create_personnel(
                None, full_name=f"Sample Person {i:02d}", phone=f"+25290000{i:04d}", service_number=f"SAMPLE-{i:04d}",
                org_unit=unit, rank=rank, status="active", effective_date=None, reason="Synthetic sample record")

    def _sample_team(self):
        """Reporting line for the member sample: Sample Person 03 (PA-10) supervises 01 (PA-03) and 02 (PA-05); the
        `bari.member` login belongs to person 03, so it sees those three records and nobody else."""
        by_no = {p.service_number: p for p in Personnel.objects.filter(service_number__startswith="SAMPLE-")}
        boss, a, b = by_no.get("SAMPLE-0003"), by_no.get("SAMPLE-0001"), by_no.get("SAMPLE-0002")
        user = User.objects.filter(username="bari.member").first()
        if not (boss and a and b and user):
            return
        Personnel.objects.filter(pk__in=[a.pk, b.pk]).update(supervisor=boss)
        if not Personnel.objects.filter(account=user).exists():
            Personnel.objects.filter(pk=boss.pk).update(account=user)

    def _sample_logistics_training(self):
        """Approve two harmless sample categories directly (DEBUG only) and add synthetic stock and assets."""
        from apps.logistics.models import Asset, InventoryCategory, StockLine
        InventoryCategory.objects.filter(code__in=["general_supplies", "vehicles"]).update(approval_status="approved")
        unit = OU.objects.get(code="BARI-ARMY-SAMPLE-A")
        supplies = InventoryCategory.objects.get(code="general_supplies")
        vehicles = InventoryCategory.objects.get(code="vehicles")
        StockLine.objects.get_or_create(category=supplies, org_unit=unit, defaults={"quantity": 40, "reorder_level": 50, "uom": "boxes"})
        for i in range(1, 4):
            Asset.objects.get_or_create(category=vehicles, identifier=f"SAMPLE-VEH-{i:03d}",
                                        defaults={"org_unit": unit, "description": "Synthetic sample vehicle"})
        self._sample_weapons_ammunition(unit)
        self._sample_ppe(unit)

    def _sample_ppe(self, unit):
        """Approve two PPE categories, stock them for the sample unit and issue some to two sample soldiers (sample only)."""
        from django.db.models import F
        from apps.logistics.models import InventoryCategory, StockLine, StockTransaction
        from apps.ppe.models import PpeMovement
        InventoryCategory.objects.filter(code__in=["ppe_helmets", "ppe_body_armour"]).update(approval_status="approved")
        if PpeMovement.objects.exists():
            return
        people = list(Personnel.objects.filter(service_number__in=["SAMPLE-0001", "SAMPLE-0002"], org_unit__path__startswith=unit.path)
                      .order_by("service_number"))
        for code, qty, size in (("ppe_helmets", 60, "L"), ("ppe_body_armour", 40, "M")):
            cat = InventoryCategory.objects.filter(code=code).first()
            if cat is None:
                continue
            line, _ = StockLine.objects.get_or_create(category=cat, org_unit=unit, defaults={"uom": "pcs", "quantity": qty, "reorder_level": 10})
            for n, person in enumerate(people):
                line.refresh_from_db()
                ref = f"SAMPLE-PPE-{code[4:9].upper()}-{n + 1}"
                txn = StockTransaction.objects.create(stock_line=line, kind="issue", delta=-1, balance_after=line.quantity - 1,
                                                      reason=f"Issued to {person.service_number}", external_ref=ref, actor_username="sample")
                StockLine.objects.filter(pk=line.pk).update(quantity=F("quantity") - 1, version=F("version") + 1)
                PpeMovement.objects.create(personnel=person, stock_line=line, kind="issue", delta=1, size=size, condition="new",
                                           reference=ref, authority_ref="Sample order 2/2026", store_transaction=txn, actor_username="sample")

    def _sample_weapons_ammunition(self, unit):
        """Synthetic weapon register entries and ammunition ledger opening balances (sample only; serials are fake)."""
        from apps.logistics.models import Asset, InventoryCategory, StockLine, StockTransaction
        from apps.weapons.models import WeaponDetail
        weapons = {  # category code: (weapon type, make/model, caliber, how many)
            "weapons_rifles": ("Assault rifle", "Sample rifle", "7.62x39 mm", 3),
            "weapons_pistols": ("Pistol", "Sample pistol", "9 mm", 2),
            "weapons_machine_guns": ("Machine gun", "Sample machine gun", "7.62x54R mm", 1),
        }
        ammo = {"ammunition_762x39": 3000, "ammunition_9mm": 800, "ammunition_762x54": 500}  # category code: opening balance (rounds)
        InventoryCategory.objects.filter(code__in=[*weapons, *ammo]).update(approval_status="approved")
        for code, (wtype, make, cal, n) in weapons.items():
            cat = InventoryCategory.objects.get(code=code)
            for i in range(1, n + 1):
                asset, _ = Asset.objects.get_or_create(category=cat, identifier=f"SAMPLE-{code[8:12].upper()}-{i:03d}",
                                                       defaults={"org_unit": unit, "description": "Synthetic sample weapon"})
                WeaponDetail.objects.get_or_create(asset=asset, defaults={"weapon_type": wtype, "make_model": make, "caliber": cal})
        for code, qty in ammo.items():
            cat = InventoryCategory.objects.get(code=code)
            line, created = StockLine.objects.get_or_create(category=cat, org_unit=unit, defaults={"uom": "rounds", "quantity": qty})
            if created:
                StockTransaction.objects.create(stock_line=line, kind="opening", delta=qty, balance_after=qty,
                                                reason="Synthetic sample opening balance", actor_username="sample")
        self._sample_soldier_holdings(unit)

    def _sample_soldier_holdings(self, unit):
        """Give two sample soldiers a weapon and some rounds, so the holdings report has something to show (sample only)."""
        from django.db.models import F
        from apps.logistics.models import Asset, StockLine, StockTransaction
        from apps.weapons.models import SoldierRounds, WeaponCustody
        if SoldierRounds.objects.exists() or WeaponCustody.objects.exists():
            return
        people = list(Personnel.objects.filter(service_number__in=["SAMPLE-0001", "SAMPLE-0002"], org_unit__path__startswith=unit.path)
                      .select_related("org_unit").order_by("service_number"))
        rifles = list(Asset.objects.filter(category__code="weapons_rifles", identifier__startswith="SAMPLE-", status="in_stock").order_by("identifier"))
        line = StockLine.objects.filter(category__code="ammunition_762x39", org_unit=unit).first()
        for n, person in enumerate(people):
            if n < len(rifles):
                a = rifles[n]
                WeaponCustody.objects.create(asset=a, personnel=person, issued_by_username="sample", authority_ref="Sample order 1/2026",
                                             issue_condition="serviceable", status_before="in_stock")
                Asset.objects.filter(pk=a.pk).update(status="issued", issued_to_unit=person.org_unit)
            if line is not None:
                issued, spent = 120 - 30 * n, 20 * (n + 1)
                line.refresh_from_db()
                txn = StockTransaction.objects.create(stock_line=line, kind="issue", delta=-issued, balance_after=line.quantity - issued,
                                                      reason=f"Issued to {person.service_number}", external_ref=f"SAMPLE-ISS-{n + 1}", actor_username="sample")
                StockLine.objects.filter(pk=line.pk).update(quantity=F("quantity") - issued, version=F("version") + 1)
                SoldierRounds.objects.create(personnel=person, stock_line=line, kind="issue", delta=issued, reference=f"SAMPLE-ISS-{n + 1}",
                                           store_transaction=txn, actor_username="sample")
                SoldierRounds.objects.create(personnel=person, stock_line=line, kind="expended", delta=-spent, note="Sample range practice", actor_username="sample")
